package com.e.indwork;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;


public class MainActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] levels = { "низький рівень", "рівень вище середнього", "середній рівень", "рівень вище середнього", "високий рівень" };
        Spinner spin1 =  findViewById(R.id.ss);
        Spinner spin2 =  findViewById(R.id.ss1);
        Spinner spin3 =  findViewById(R.id.ss2);
        Spinner spin4 =  findViewById(R.id.ss3);
        Spinner spin5 =  findViewById(R.id.ss4);
        Spinner spin6 =  findViewById(R.id.ss5);
        Spinner spin7 =  findViewById(R.id.ss6);
        Spinner spin8 =  findViewById(R.id.ss7);
        Spinner spin9 =  findViewById(R.id.ss8);
        Spinner spin10 = findViewById(R.id.ss9);
        EditText ss1 = findViewById(R.id.editText1);
        EditText ss2 = findViewById(R.id.editText2);
        EditText ss3 = findViewById(R.id.editText3);
        EditText ss4 = findViewById(R.id.editText4);
        EditText ss5 = findViewById(R.id.editText5);
        EditText ss6 = findViewById(R.id.editText6);
        EditText ss7 = findViewById(R.id.editText7);
        EditText ss8 = findViewById(R.id.editText8);
        EditText ss9 = findViewById(R.id.editText9);
        EditText ss10 = findViewById(R.id.editText10);
        ss1.setFilters(new InputFilter[]{ new InputFilterMinMax("0.1", "0.99")});
        ss2.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss3.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss4.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss5.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss6.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss7.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss8.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss9.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ss10.setFilters(new InputFilter[]{ new InputFilterMinMax("0", "1")});
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, levels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin1.setAdapter(adapter);
        spin2.setAdapter(adapter);
        spin3.setAdapter(adapter);
        spin4.setAdapter(adapter);
        spin5.setAdapter(adapter);
        spin6.setAdapter(adapter);
        spin7.setAdapter(adapter);
        spin8.setAdapter(adapter);
        spin9.setAdapter(adapter);
        spin10.setAdapter(adapter);
    }

}
